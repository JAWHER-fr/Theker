
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addMajlis, getMajalis } from '../storage';

const CreateMajlisPage = () => {
  const [title, setTitle] = useState('');
  const navigate = useNavigate();

  const handleCreate = () => {
    const newMajlis = {
      id: getMajalis().length + 1,
      title,
      time: 'وقت غير محدد',
      description: 'مجلس جديد',
    };
    addMajlis(newMajlis);
    navigate('/');
  };

  return (
    <div className="p-4 max-w-md mx-auto text-right">
      <h1 className="text-2xl mb-4">إنشاء مجلس جديد</h1>
      <input
        type="text"
        placeholder="اسم المجلس"
        value={title}
        onChange={e => setTitle(e.target.value)}
        className="w-full p-2 border rounded mb-4"
      />
      <button onClick={handleCreate} className="bg-green-500 text-white px-4 py-2 rounded">
        إنشاء
      </button>
    </div>
  );
};

export default CreateMajlisPage;
