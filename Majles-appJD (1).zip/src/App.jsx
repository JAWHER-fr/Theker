
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import CreateMajlisPage from './pages/CreateMajlisPage';
import MajlisDetailPage from './pages/MajlisDetailPage';
import JoinMajlisPage from './pages/JoinMajlisPage';

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/create" element={<CreateMajlisPage />} />
      <Route path="/majlis/:id" element={<MajlisDetailPage />} />
      <Route path="/majlis/:id/join" element={<JoinMajlisPage />} />
    </Routes>
  </Router>
);

export default App;
