
export const getMajalis = () => {
  const data = localStorage.getItem('majalis');
  return data ? JSON.parse(data) : [];
};

export const addMajlis = (majlis) => {
  const data = getMajalis();
  data.push(majlis);
  localStorage.setItem('majalis', JSON.stringify(data));
};

export const getMajlisById = (id) => {
  return getMajalis().find(m => m.id === parseInt(id));
};
